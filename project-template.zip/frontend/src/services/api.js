import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
});

export const getExampleData = () => api.get('/example');
